package com.example.GoogleOauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoogleOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
