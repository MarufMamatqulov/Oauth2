package com.example.GoogleOauth.service;

import com.example.GoogleOauth.domain.User;
import com.example.GoogleOauth.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    public User getUserFromAuthentication(AbstractAuthenticationToken authentication) {
        Map<String, Object> attributes;
        if (authentication instanceof OAuth2AuthenticationToken) {
            attributes = ((OAuth2AuthenticationToken) authentication).getPrincipal().getAttributes();
        } else {
            throw new IllegalArgumentException("Error");
        }

        User user = new User();
        user.setEmail((String) attributes.get("email"));
        user.setFirstName((String) attributes.get("given_name"));
        user.setLastName((String) attributes.get("family_name"));
        user.setActivated((boolean) attributes.get("email_verified"));
        user.setLangKey((String) attributes.get("locale"));
        user.setImageUrl((String) attributes.get("picture"));
        user.setUid((String) attributes.get("id"));


        // Save user to database
        user = userRepository.save(user);

        // Send email notification
        emailService.sendEmail(
                user.getEmail(),
                "Account Authorization",
                "Your account has successfully authorized in our system."
        );

        return user;
    }

}
